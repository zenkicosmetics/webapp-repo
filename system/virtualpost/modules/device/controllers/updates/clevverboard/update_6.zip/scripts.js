$(document).ready(function()
{
	$.getJSON("data.json", function (data) {

		var options = {
			valueNames: [ 'company', 'name' ],
			item: '<li><h3 class="company"></h3><p class="name"></p></li>',
			plugins: [ ListFuzzySearch() ]
		};
		var data_formated = [];
		for (key in data.data) {
			data_formated.push({
				company: data.data[key][0],
				name: data.data[key][1]
			});
		}

		var addressList = new List('customers-list', options, data_formated);

		var scrollPane = $('#customers-list').jScrollPane(
			{
				showArrows: true,
				verticalArrowPositions: 'split',
				horizontalArrowPositions: 'split'
			}
		);
		var scrollPaneApi = scrollPane.data('jsp');

		$('.scrollbar .scroll_up').on('mousedown', function() {
				var interval = setInterval(
					function() {
						scrollPaneApi.scrollByY(-30);
					},
					100
				);
				$(this).on('mouseup', function() {
					clearInterval(interval);
					$(document).unbind('.jspExample');
				});
			}
		);
		$('.scrollbar .scroll_down').on('mousedown', function() {
				var interval = setInterval(
					function() {
						scrollPaneApi.scrollByY(30);
					},
					100
				);
				$(this).on('mouseup', function() {
					clearInterval(interval);
					$(document).unbind('.jspExample');
				});
			}
		);

		$('#keyboard').keyboard({
			layout: 'custom',
			customLayout: {
				'default': [
					'{b} {clear}',
					'A B C D E F',
					'G H I J K L',
					'M N O P Q R',
					'S T U V W X',
					'Y Z Ä Ö Ü ß',
					'1 2 3 4 5 6',
					'7 8 9 0 ! &',
					'{space}'
				]
			},
			display: {
				'clear': ' ',
				'space': 'SPACE',
				'b': ' '
			},
			alwaysOpen: true,
			stayOpen: true,
			preventPaste: true,
			accepted: function (e, keyboard, el) {
				alert($(this).val());
			},
			change: function (e, keyboard, el) {
				var search = keyboard.$preview.val();
				addressList.fuzzySearch.search(search).update();
			}
		});

		$('input.ui-keyboard-preview').attr('placeholder', 'Enter name...');
	});
	//$("#panel-left").tinyscrollbar({ trackSize: 100 });

	setInterval(function(){ reload_page_tester() }, 600000);

	var search_field_val = $('.ui-keyboard-preview-wrapper input').val();
	function reload_page_tester() {
		var new_search_field_val = $('.ui-keyboard-preview-wrapper input').val();
		if (search_field_val == new_search_field_val) {
			location.reload();
		}
		search_field_val = new_search_field_val;
	}
});