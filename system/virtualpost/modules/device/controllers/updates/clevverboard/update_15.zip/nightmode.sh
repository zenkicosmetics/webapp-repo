[ $(date "+%H%M") -ge 2000 ] && {
	xset dpms force off
	exit 1
}
[ $(date "+%H%M") -le 600 ] && {
	xset dpms force off
	exit 1
}
xset dpms force on