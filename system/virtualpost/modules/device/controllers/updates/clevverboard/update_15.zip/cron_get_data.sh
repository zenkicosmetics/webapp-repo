#!/bin/bash

# LOAD CONFIG
. "./config.sh"

device_id=$(cat $device_id_file)
device_secret=$(cat $device_secret_file)

wget --timeout=20 --tries=3 "${remote_host_protocol}://${remote_host}${path_on_server}get_data?device_id=${device_id}&secret_key=${device_secret}" -O data.json.tmp

if [[ -s data.json.tmp ]] ; then
rm data.json
mv data.json.tmp data.json
else
rm data.json.tmp
fi ;

timezone=$(cat data.json | ./jq -r '.device.timezone')
sudo bash -c "echo $timezone > /etc/timezone"