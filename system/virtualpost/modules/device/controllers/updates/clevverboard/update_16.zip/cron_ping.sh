#!/bin/bash

# LOAD CONFIG
. "./config.sh"

device_id=$(cat $device_id_file)
device_secret=$(cat $device_secret_file)
clevverboard_revision=$(cat $clevverboard_revision_file)
clevverboard_last_data_update=$(cat data.json | ./jq -r '.last_modified')

# PING
wget --timeout=20 --tries=3 "${remote_host_protocol}://${remote_host}${path_on_server}ping?device_id=${device_id}&secret_key=${device_secret}&revision=${clevverboard_revision}&last_data_update=${clevverboard_last_data_update}" -O /dev/null