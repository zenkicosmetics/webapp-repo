#!/bin/bash

if ps aux | grep "[f]irefox" > /dev/null
then
    echo "Firefox is already running."
else
    firefox
fi

wmctrl -a firefox -b toggle,above
