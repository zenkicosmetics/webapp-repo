crontab -l > clevverboard-crontab
sed -i 's/.\/cron_firefox_front.sh/export DISPLAY=:0 \&\& .\/cron_firefox_front.sh/g' clevverboard-crontab
crontab clevverboard-crontab
rm clevverboard-crontab
