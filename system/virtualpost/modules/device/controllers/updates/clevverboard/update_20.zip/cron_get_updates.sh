#!/bin/bash

# LOAD CONFIG
. "./config.sh"

device_id=$(cat $device_id_file)
device_secret=$(cat $device_secret_file)
clevverboard_revision=$(cat $clevverboard_revision_file)

wget --timeout=20 --tries=3 "${remote_host_protocol}://${remote_host}${path_on_server}get_updates?device_id=${device_id}&secret_key=${device_secret}&last_revision=${clevverboard_revision}" -O update.zip


if [[ -s update.zip ]]; then
	unzip -o update.zip
	rm update.zip

	sudo chown -R user:user *
	sudo chmod -R 0777 *

	if [[ -s update.sh ]]; then
		chmod u+x update.sh
		sudo ./update.sh
		rm update.sh
	fi ;
else
	echo 'nothing to update.'
	exit
fi ;

sudo chown -R user:user *
sudo chmod -R 0777 *
