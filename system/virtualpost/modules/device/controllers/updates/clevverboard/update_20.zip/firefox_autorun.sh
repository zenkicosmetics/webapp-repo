#!/bin/bash

firefox &
sleep 10s
export DISPLAY=:0
wmctrl -a firefox -b toggle,above
sleep 10s
xdotool key ctrl+F5