update-locale LANGUAGE=en_US LC_CTYPE=en_US.UTF-8 LC_ALL=en_US.UTF-8

apt-get -y update
apt-get -y upgrade
apt-get -y install xserver-xorg-input-void
apt-get -y install --install-recommends linux-generic-lts-trusty xserver-xorg-lts-trusty libgl1-mesa-glx-lts-trusty
apt-get -y install -d --reinstall network-manager network-manager-gnome

reboot
