#!/bin/bash

line=$(ps aux | grep -s "[f]irefox" | grep -sv "cron_firefox")
echo "line = ${line}"
if [ -z "${line}" ]
then
    export DISPLAY=:0
    firefox &
    wmctrl -a firefox -b toggle,above
    sleep 5s
    xdotool key ctrl+F5
else
    echo "Firefox is already running."
fi
