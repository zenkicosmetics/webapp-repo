#!/bin/bash

X_DISPLAY=":0"
X_OUTPUT="LVDS-0"
time_idle_day=600000
time_idle_night=60000
time_idle_current=0
state=0
user_name="user"
brightness_on=1
brightness_idle=0.4
brightness_night=0
brightness_current=0

xset -display $X_DISPLAY s off -dpms
gsettings set org.gnome.desktop.session idle-delay 0
gsettings set org.gnome.settings-daemon.plugins.power active false

while true
do
    IDLE=`export DISPLAY=$X_DISPLAY && sudo -u $user_name xprintidle`
    NOW=`date "+%H%M"`
    if [ $NOW -ge 2000 -a $NOW -le 2359 ] || [ $NOW -ge 0 -a $NOW -le 600 ]
    then
		brightness_current=$brightness_night
		time_idle_current=$time_idle_night
		sleep_mode="nigth"
    else
		brightness_current=$brightness_idle
		time_idle_current=$time_idle_day
		sleep_mode="idle"
    fi
	if [ $IDLE -gt $time_idle_current ]
	then
		if [ $state -eq 0 ]
		then
			xrandr -d :0 --output $X_OUTPUT --brightness $brightness_current
			state=1
		fi
	else
		if [ $state -eq 1 ]
		then
			xrandr -d :0 --output $X_OUTPUT --brightness $brightness_on
			state=0
		fi
	fi
    sleep 1s
done
