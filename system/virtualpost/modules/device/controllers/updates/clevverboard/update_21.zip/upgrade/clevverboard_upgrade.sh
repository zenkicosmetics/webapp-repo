#!/bin/bash

sudo update-locale LANGUAGE=en_US LC_CTYPE=en_US.UTF-8 LC_ALL=en_US.UTF-8

sudo apt-get -y update
sudo apt-get -y upgrade
sudo apt-get -y install xserver-xorg-input-void mc
sudo apt-get -y install --install-recommends linux-generic-lts-trusty xserver-xorg-lts-trusty libgl1-mesa-glx-lts-trusty
sudo apt-get -y install -d --reinstall network-manager network-manager-gnome
sudo apt-get -y install wmctrl xdotool xprintidle

crontab -r
echo "*/5 * * * * cd /home/user/clevverboard && ./cron_ping.sh" > clevverboard-crontab
echo "*/5 * * * * cd /home/user/clevverboard && ./cron_firefox_front.sh" >> clevverboard-crontab
echo "5 * * * * cd /home/user/clevverboard && ./cron_get_data.sh" >> clevverboard-crontab
echo "0 1 * * * cd /home/user/clevverboard && ./cron_get_updates.sh" >> clevverboard-crontab
crontab clevverboard-crontab
rm clevverboard-crontab

# SET STARTUP Fierefox SCRIPT
xsession_path=~/.config/autostart/clevverboard.desktop
bash -c "echo '[Desktop Entry]' > $xsession_path"
bash -c "echo 'Type=Application' >> $xsession_path"
bash -c "echo 'Exec=/home/user/clevverboard/firefox_autorun.sh' >> $xsession_path"
bash -c "echo 'Hidden=false' >> $xsession_path"
bash -c "echo 'NoDisplay=false' >> $xsession_path"
bash -c "echo 'X-GNOME-Autostart-enabled=true' >> $xsession_path"
bash -c "echo 'Name=Firefox' >> $xsession_path"
bash -c "echo 'Comment=Firefox' >> $xsession_path"

# SET STARTUP Dimemr SCRIPT
xsession_path=~/.config/autostart/dimmer.desktop
bash -c "echo '[Desktop Entry]' > $xsession_path"
bash -c "echo 'Type=Application' >> $xsession_path"
bash -c "echo 'Exec=/home/user/clevverboard/clevverboard_dimmer.sh &' >> $xsession_path"
bash -c "echo 'Hidden=false' >> $xsession_path"
bash -c "echo 'NoDisplay=false' >> $xsession_path"
bash -c "echo 'X-GNOME-Autostart-enabled=true' >> $xsession_path"
bash -c "echo 'Name=Dimmer' >> $xsession_path"
bash -c "echo 'Comment=Clevverboard Dimmer' >> $xsession_path"

sudo rm -fr /home/user/clevverboard/upgrade
sudo reboot

exit;
