#!/bin/bash

# CONFIG
device_id_file="./DEVICE_ID"
device_secret_file="./.DEVICE_SECRET"
clevverboard_revision_file="./CUR_REVISION"
remote_host_protocol="https"
remote_host="node2.eu.clevvermail.com"
path_on_server="/app/index.php/device/"
#remote_host="clevvermail.dev"
#path_on_server="/device/"